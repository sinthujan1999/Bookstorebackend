package com.bookshop.models;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Bookshop")
public class Bookshop {
	    @Id
	    private String id;
		private String title;
		private Integer isbnNumber;
		private Integer price;
		private String language;
		private String genre;
		private String date;
		public Bookshop(String id, String title, Integer isbnNumber, Integer price, String language, String genre,
				String date) {
			super();
			this.id = id;
			this.title = title;
			this.isbnNumber = isbnNumber;
			this.price = price;
			this.language = language;
			this.genre = genre;
			this.date = date;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public Integer getIsbnNumber() {
			return isbnNumber;
		}
		public void setIsbnNumber(Integer isbnNumber) {
			this.isbnNumber = isbnNumber;
		}
		public Integer getPrice() {
			return price;
		}
		public void setPrice(Integer price) {
			this.price = price;
		}
		public String getLanguage() {
			return language;
		}
		public void setLanguage(String language) {
			this.language = language;
		}
		public String getGenre() {
			return genre;
		}
		public void setGenre(String genre) {
			this.genre = genre;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		@Override
		public String toString() {
			return "Bookshop [id=" + id + ", title=" + title + ", isbnNumber=" + isbnNumber + ", price=" + price
					+ ", language=" + language + ", genre=" + genre + ", date=" + date + "]";
		}
		
}
