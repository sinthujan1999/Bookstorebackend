package com.bookshop.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bookshop.exception.RecordNotFoundException;
import com.bookshop.models.Bookshop;
import com.bookshop.repository.BookShopRepository;

@Service
public class BookshopServices {

	@Autowired
	BookShopRepository bookShopRepository;

	public ResponseEntity<List<Bookshop>> getAllBookDetails() {
		List<Bookshop> bookShop = new ArrayList<Bookshop>();
		bookShopRepository.findAll().forEach(bookShop::add);
	
	    if (bookShop.isEmpty()) {
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	    return new ResponseEntity<>(bookShop, HttpStatus.OK);
	}



	public ResponseEntity<Bookshop> createBookDetails( Bookshop bookshop) {
		

		try {
			Date date= new Date();
			bookshop.setDate(date.getHours()+":"+date.getMinutes());
			Bookshop bookshops =bookShopRepository.insert(bookshop);
			
			return new ResponseEntity<>(bookshops,HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}




	public ResponseEntity<HttpStatus> deleteBookDetailsbyId(String id) throws RecordNotFoundException
	{
		Optional<Bookshop> deleteBookshop = bookShopRepository.findById(id);
			if(deleteBookshop.isPresent()) {
				bookShopRepository.delete(deleteBookshop.get());
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}else {
				throw new RecordNotFoundException("Not Deleted by this"+id);
			
			}
			
		}



	public ResponseEntity<HttpStatus> deleteAllBookDetails() {
		try {
			List<Bookshop>bookshop=bookShopRepository.findAll();
			
			if (bookshop.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			} else {
				bookShopRepository.deleteAll(bookshop);
			}
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		}






	public ResponseEntity<Map<String, Object>> getAllBookDetailsInPage(int pageNo, int pageSize, String sortBy) {
		 try {
	   		 Map<String, Object> response = new HashMap<>();
	   	 	Sort sort = Sort.by(sortBy);
	   		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
	   	 	Page<Bookshop> page = bookShopRepository.findAll(pageable);
	   	 	response.put("data", page.getContent());
	   	 	response.put("Total_no_of_pages", page.getTotalPages());
	   	 	response.put("Total_no_of_elements", page.getTotalElements());
	   	 	response.put("Current_page_no", page.getNumber());
	   		 
	   	 	return new ResponseEntity<>(response, HttpStatus.OK);
	   	 } catch (Exception e) {
	   	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	   	 }

		
	}




	public ResponseEntity<Bookshop> updateBookDetails(String id, Bookshop bookshop) {
		 Optional<Bookshop> bookshopData = bookShopRepository.findById(id);

	   	 if (bookshopData.isPresent()) {
	   		Bookshop _bookshop = bookshopData.get();
	   		_bookshop.setTitle(bookshop.getTitle());
	   		_bookshop.setIsbnNumber(bookshop.getIsbnNumber());
	   		_bookshop.setLanguage(bookshop.getLanguage());
	   		_bookshop.setPrice(bookshop.getPrice());
	   		_bookshop.setGenre(bookshop.getGenre());
			
	   	 	return new ResponseEntity<>(bookShopRepository.save(_bookshop), HttpStatus.OK);
	   	 } else {
	   	 	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	   	 }

	}




}
