package com.bookshop.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookshop.exception.RecordNotFoundException;
import com.bookshop.models.Bookshop;
import com.bookshop.services.BookshopServices;


@CrossOrigin("*")
@RestController
@RequestMapping("/api/auth/bookshop")
public class BookShopController {
	
	@Autowired
	private BookshopServices bookshopservices;
	
	
	      @GetMapping
			  public ResponseEntity<List<Bookshop>> getAllBookDetails() {
			        return bookshopservices.getAllBookDetails();
			           }
			 
		
		  @DeleteMapping(value = "/{id}")  
			  public ResponseEntity<HttpStatus> deleteBookDetailsbyId(@PathVariable String id) throws RecordNotFoundException {
			        return bookshopservices.deleteBookDetailsbyId(id);
			           }
			  
		   @PostMapping
		      public ResponseEntity<Bookshop> createServicestation(@Valid  @RequestBody Bookshop bookshop) {
		            return bookshopservices.createBookDetails(bookshop);
				       }
				        
		   @DeleteMapping
		   	  public void deleteAllServicestation() throws RecordNotFoundException {
			           bookshopservices.deleteAllBookDetails();
			    }
		   @GetMapping("/page")
			public ResponseEntity<Map<String, Object>> getAllBookDetailsInPage(
		  		 @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
		  		 @RequestParam(name = "pageSize", defaultValue = "2") int pageSize,
		  		 @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
		  	 return bookshopservices.getAllBookDetailsInPage(pageNo, pageSize, sortBy);
		   }
		
		
		   @PutMapping("/{id}")
		   public ResponseEntity<Bookshop> updateBookDetails(@PathVariable String id, @RequestBody Bookshop bookshop) {
		       return bookshopservices.updateBookDetails(id,bookshop);
		   }


}
