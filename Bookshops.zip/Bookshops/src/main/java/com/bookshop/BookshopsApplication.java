package com.bookshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookshopsApplication.class, args);
	}

}
